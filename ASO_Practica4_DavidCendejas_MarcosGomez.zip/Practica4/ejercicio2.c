#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>

#define MAXMSJ 1024

void manejarSIGUSR1(int sig);
void manejarSIGUSR2(int sig);

volatile sig_atomic_t hijoListo = 0;

// En este ejercicio, un padre y un hijo se comunican mediante señales (SIGUSR1, SIGUSR2) y un archivo (mailbox), repitiendo el intercambio hasta que el padre recibe EOF y finaliza con SIGTERM.

int main() {
    char mensaje[MAXMSJ]; 
    pid_t pid;
    int pauseSecs = 1; 
    char *val;

    // Acceder a la variable de entorno PAUSASECS
    val = getenv("PAUSASECS");
    if (val != NULL) {
        pauseSecs = atoi(val); // Si PAUSASECS está definida, usar su valor
    }

    // Crear un proceso hijo
    pid = fork();
    if (pid == -1) {
        perror("Error en fork");
        return 1;
    }

    if (pid > 0) {   // Proceso padre
        struct sigaction sa;
        sa.sa_handler = manejarSIGUSR2; // Establecer el manejador para SIGUSR2
        sigemptyset(&sa.sa_mask);
        sa.sa_flags = 0;
        sigaction(SIGUSR2, &sa, NULL);

        while (fgets(mensaje, MAXMSJ, stdin) != NULL) { // Leer mensaje de la entrada estándar
            FILE *mailbox = fopen("mailbox", "w");
            if (mailbox == NULL) {
                perror("Error al abrir archivo");
                exit(1);
            }
            fputs(mensaje, mailbox); // Escribir mensaje en el archivo
            fflush(mailbox); // Asegurar que el mensaje se escriba en disco
            fclose(mailbox); // Cerrar el archivo

            kill(pid, SIGUSR1); // Enviar señal SIGUSR1 al hijo para notificar que hay un mensaje

            // Esperar a que el hijo lea el mensaje
            while (!hijoListo) {
                pause(); 
            }
            hijoListo = 0; 

            sleep(pauseSecs); // Pausar el proceso por el tiempo especificado en segundos
        }
        printf("Enviando signal SIGTERM al hijo.\n");
        kill(pid, SIGTERM); // Enviar señal SIGTERM al hijo para que termine
        printf("Proceso padre termina.\n");

    } else {    // Proceso hijo
        struct sigaction sa;
        sa.sa_handler = manejarSIGUSR1; // Establecer el manejador para SIGUSR1
        sigemptyset(&sa.sa_mask);
        sa.sa_flags = 0;
        sigaction(SIGUSR1, &sa, NULL);

        while (1) {
            pause(); // Esperar a recibir una señal
        }
    }

    return 0;
}

// Manejador de señal SIGUSR1 (usado por el hijo)
// Abre el mailbox.txt, lee el mensaje y lo imprime, despues notifica al padre
void manejarSIGUSR1(int sig) {
    FILE *mailbox = fopen("mailbox", "r"); // Abrir archivo mailbox para lectura
    if (mailbox == NULL) {
        perror("Hijo no puede abrir el archivo");
        exit(1);
    }

    char mensaje[MAXMSJ]; 
    if (fgets(mensaje, MAXMSJ, mailbox) != NULL) { 
        printf("Hijo recibió: %s", mensaje); 
    }

    fclose(mailbox); 
    kill(getppid(), SIGUSR2); // Enviar señal SIGUSR2 al padre para notificar que el hijo está listo
}

// Manejador de señal SIGUSR2 (usado por el padre)
void manejarSIGUSR2(int sig) {
    hijoListo = 1;
}

