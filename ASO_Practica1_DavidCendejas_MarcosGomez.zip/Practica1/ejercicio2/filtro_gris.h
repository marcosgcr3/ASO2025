#ifndef FILTRO_GRIS_H
#define FILTRO_GRIS_H

#include "ppm.h"

void filtro_gris(ImagenPPM *img);

#endif