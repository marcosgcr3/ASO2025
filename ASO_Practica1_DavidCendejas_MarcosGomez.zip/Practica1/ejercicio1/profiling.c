#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>
#include "ppm.c"

// Utilizados como apoyo ppm.c y ppm.h del ejercicio 2

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Uso: %s <ruta_imagen.ppm> <iteraciones>\n", argv[0]);
        return EXIT_FAILURE;
    }

    //Se reciben la ruta del archivo y el numero de iteraciones
    const char *archivo = argv[1];
    int iteraciones = atoi(argv[2]);
    if (iteraciones <= 0) {
        fprintf(stderr, "El número de iteraciones debe ser mayor que 0\n");
        return EXIT_FAILURE;
    }

    struct timespec inicio, fin;
    long tiempo_minimo = LONG_MAX, tiempo_maximo = 0, tiempo_total = 0;

    for (int i = 0; i < iteraciones; i++) {
        clock_gettime(CLOCK_MONOTONIC, &inicio);
        ImagenPPM *imagen = leer_ppm(archivo);
        clock_gettime(CLOCK_MONOTONIC, &fin);
        
        if (!imagen) {
            fprintf(stderr, "Error al cargar la imagen\n");
            return EXIT_FAILURE;
        }
        
        liberar_ppm(imagen);
        
        long cambioUnidades = 1000000000; //Para pasar de segundos a nanosegundos
        long tiempo_transcurrido = (fin.tv_sec - inicio.tv_sec) * cambioUnidades + (fin.tv_nsec - inicio.tv_nsec);
        tiempo_total += tiempo_transcurrido;
        if (tiempo_transcurrido < tiempo_minimo) tiempo_minimo = tiempo_transcurrido;
        if (tiempo_transcurrido > tiempo_maximo) tiempo_maximo = tiempo_transcurrido;
    }

    printf("Tiempo medio: %ld ns\n", tiempo_total / iteraciones);
    printf("Tiempo mínimo: %ld ns\n", tiempo_minimo);
    printf("Tiempo máximo: %ld ns\n", tiempo_maximo);

    return EXIT_SUCCESS;
}
