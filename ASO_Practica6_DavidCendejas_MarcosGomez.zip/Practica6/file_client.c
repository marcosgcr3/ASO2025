#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <mqueue.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#define SERVER_QUEUE "/file_server_queue" 
#define MAX_MSG_SIZE 8192 

int main(int argc, char *argv[]) {
    // Verifica que el número de argumentos sea correcto
    if (argc != 2) {
        fprintf(stderr, "Uso: %s <ruta-archivo>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Crea el nombre de la cola de mensajes del cliente basado en el ID del proceso (PID)
    char client_queue_name[64];
    snprintf(client_queue_name, sizeof(client_queue_name), "/client_queue_%d", getpid());
    
    printf("La cola de mensajes del cliente es: %s\n", client_queue_name);  // DEBUG

    // Atributos de la cola de mensajes del cliente (definimos el tamaño máximo del mensaje y la cantidad máxima de mensajes)
    struct mq_attr attr = {
        .mq_flags = 0,  			// Sin opciones de flags
        .mq_maxmsg = 10,  			// Número máximo de mensajes en la cola
        .mq_msgsize = MAX_MSG_SIZE, // Tamaño máximo de cada mensaje
        .mq_curmsgs = 0  			// Número actual de mensajes en la cola
    };

    // Abre la cola de mensajes del cliente (O_CREAT crea la cola si no existe)
    mqd_t client_q = mq_open(client_queue_name, O_CREAT | O_RDONLY, 0660, &attr);
    if (client_q == (mqd_t)-1) {
        perror("mq_open - cliente");  
        exit(EXIT_FAILURE);
    }

    // Abre la cola de mensajes del servidor para enviar solicitudes (O_WRONLY abre solo para escritura)
    mqd_t server_q = mq_open(SERVER_QUEUE, O_WRONLY);
    if (server_q == (mqd_t)-1) {
        perror("mq_open - servidor"); 
        mq_unlink(client_queue_name);  // Elimina la cola del cliente si no se puede abrir la cola del servidor
        exit(EXIT_FAILURE);
    }

    // Estructura que contiene el nombre de la cola del cliente y la ruta del archivo solicitado
    struct {
        char client_queue[64];  // Cola del cliente
        char filepath[1024]; 	// Ruta del archivo solicitado
    } req;

    // Copia el nombre de la cola del cliente y la ruta del archivo en la estructura
    strncpy(req.client_queue, client_queue_name, sizeof(req.client_queue));
    strncpy(req.filepath, argv[1], sizeof(req.filepath));

    printf("La ruta del archivo es: %s\n", req.filepath);  // DEBUG

    // Envía la solicitud (estructura `req`) a la cola del servidor
    if (mq_send(server_q, (char*)&req, sizeof(req), 0) == -1) {
        perror("mq_send"); 
        exit(EXIT_FAILURE);
    }

    // Buffer para almacenar los datos que recibirá el cliente
    char buffer[MAX_MSG_SIZE];
    unsigned prio;  // prioridad del mensaje recibido
    ssize_t len;  	// Longitud del mensaje recibido

    // Bucle que recibe los mensajes desde la cola del cliente
    while ((len = mq_receive(client_q, buffer, MAX_MSG_SIZE, &prio)) >= 0) {
        if (prio == 1) {  			// Error en el servidor
            fprintf(stderr, "%s\n", buffer);
            break;  
        } else if (prio == 2) { 	// Servidor ha enviado datos del archivo, los escribe en la salida estándar
            write(STDOUT_FILENO, buffer, len);
        } else if (prio == 3) {  	// Servidor ha terminado de enviar los datos
            break;  
        }
    }

    // Cierra la cola de mensajes del cliente y la elimina
    mq_close(client_q);
    mq_unlink(client_queue_name);

    return 0; 
}
