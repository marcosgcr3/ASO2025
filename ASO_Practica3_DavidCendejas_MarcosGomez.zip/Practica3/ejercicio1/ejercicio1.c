#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 5) {
        fprintf(stderr, "Uso: %s comando1 argumento1 comando2 argumento2\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int pipefd[2];  //pipefd[0] es el extremo de lectura y pipefd[1] el de escritura.
    
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

	// Proceso hijo
    if (pid == 0) { 
        close(pipefd[1]); 				// Cierra el extremo de escritura no necesario
        dup2(pipefd[0], STDIN_FILENO);  // Redirecciona la entrada estándar al extremo de lectura del pipe
        close(pipefd[0]); 				// Ya no se necesita el descriptor original

        execlp(argv[3], argv[3], argv[4], (char *)NULL);
        perror("execlp hijo");
        exit(EXIT_FAILURE);
    } 
    // Proceso padre
    else { 
        close(pipefd[0]); 				// Cierra el extremo de lectura no necesario
        dup2(pipefd[1], STDOUT_FILENO); // Redirecciona la salida estándar al extremo de escritura del pipe
        close(pipefd[1]); 				// Ya no se necesita el descriptor original

        execlp(argv[1], argv[1], argv[2], (char *)NULL);
        perror("execlp padre");
        exit(EXIT_FAILURE);
    }
}
