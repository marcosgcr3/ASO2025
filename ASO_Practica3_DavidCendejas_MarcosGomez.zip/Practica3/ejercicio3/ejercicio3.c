#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <sys/wait.h>
#define BUFFER_SIZE 1024

void to_uppercase(char *str) {
    while (*str) {
        *str = toupper((unsigned char) *str);
        str++;
    }
}

int main(void) {
    int pipe_padre_hijo[2], pipe_hijo_padre[2];
    char buffer[BUFFER_SIZE];
    int num_mensajes = 0;

    // Crear las tuberías
    if (pipe(pipe_padre_hijo) == -1 || pipe(pipe_hijo_padre) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { // Proceso hijo
        close(pipe_padre_hijo[1]); // Cierra el extremo de escritura 
        close(pipe_hijo_padre[0]); // Cierra el extremo de lectura 

        while (1) {
            ssize_t bytes_leidos = read(pipe_padre_hijo[0], buffer, BUFFER_SIZE - 1);
            if (bytes_leidos > 0) {
                buffer[bytes_leidos] = '\0';
                to_uppercase(buffer);
                printf("Hijo recibe: %s\n", buffer);
                sleep(1); // Espera durante 1 segundo

                char respuesta = (num_mensajes < 9) ? 'n' : 'q';
                write(pipe_hijo_padre[1], &respuesta, 1);
                num_mensajes++;

                if (respuesta == 'q') {
                    break;
                }
            } else {
                break; // Salir del bucle si no hay nada que leer
            }
        }

        close(pipe_padre_hijo[0]);
        close(pipe_hijo_padre[1]);
    } else { // Proceso padre
        close(pipe_padre_hijo[0]); // Cierra el extremo de lectura 
        close(pipe_hijo_padre[1]); // Cierra el extremo de escritura 

        while (1) {
            printf("Padre envía: ");
            fflush(stdout);
            if (fgets(buffer, BUFFER_SIZE, stdin) == NULL) {
                break; // Salir del bucle si fgets falla
            }
            if (buffer[strlen(buffer) - 1] == '\n') {
                buffer[strlen(buffer) - 1] = '\0'; // Eliminar el salto de línea
            }

            write(pipe_padre_hijo[1], buffer, strlen(buffer));

            char confirmacion;
            read(pipe_hijo_padre[0], &confirmacion, 1);
            if (confirmacion == 'q') {
                break; // Finalizar si se recibe 'q'
            }
        }

        close(pipe_padre_hijo[1]);
        close(pipe_hijo_padre[0]);
        wait(NULL); // Esperar a que el hijo termine
    }

    return EXIT_SUCCESS;
}
