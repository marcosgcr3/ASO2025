#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <errno.h>

int main(int argc, char *argv[]){
    if(argc != 3){
        fprintf(stderr, "Usage: %s <pipe_name1> <pipe_name2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *pipe_name1 = argv[1];
    char *pipe_name2 = argv[2];

    // Intentar crear la primera tubería
    if(mkfifo(pipe_name1, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    // Intentar crear la segunda tubería
    if(mkfifo(pipe_name2, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    int fd1 = open(pipe_name1, O_RDONLY | O_NONBLOCK);
    int fd2 = open(pipe_name2, O_RDONLY | O_NONBLOCK);
    if(fd1 == -1 || fd2 == -1){
        perror("open");
        exit(EXIT_FAILURE);
    }

    fd_set rfds;
    struct timeval tv;
    char buf[1024];

    while(1){
        FD_ZERO(&rfds);
        FD_SET(fd1, &rfds);
        FD_SET(fd2, &rfds);

        // Configurar el timeout
        tv.tv_sec = 5;
        tv.tv_usec = 0;

        int retval = select(fd2 + 1, &rfds, NULL, NULL, &tv);   //espere hasta que haya datos listos para leer 
        if(retval == -1){
            perror("select");
            exit(EXIT_FAILURE);
        }else if(retval){
            // Leer de fd1 si está listo
            if(FD_ISSET(fd1, &rfds)){
                ssize_t readBytes = read(fd1, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Lectura de %s: %s\n", pipe_name1, buf);
                }
            }
            // Leer de fd2 si está listo
            if(FD_ISSET(fd2, &rfds)){
                ssize_t readBytes = read(fd2, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Lectura de %s: %s\n", pipe_name2, buf);
                }
            }
        }else{
            printf("Sin datos en los ultimos 5 segundos.\n");
        }
    }

    close(fd1);
    close(fd2);
    unlink(pipe_name1);
    unlink(pipe_name2);

    return 0;
}

