#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <errno.h>

int main(int argc, char *argv[]){
    if(argc != 3){
        fprintf(stderr, "Uso: %s <nombre_tubería1> <nombre_tubería2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *nombre_tubería1 = argv[1];
    char *nombre_tubería2 = argv[2];

    if(mkfifo(nombre_tubería1, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }
    if(mkfifo(nombre_tubería2, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    int fd1 = open(nombre_tubería1, O_RDONLY | O_NONBLOCK);
    int fd2 = open(nombre_tubería2, O_RDONLY | O_NONBLOCK);
    if(fd1 == -1 || fd2 == -1){
        perror("open");
        exit(EXIT_FAILURE);
    }

    fd_set rfds;
    struct timeval tv;
    char buf[1024];
    int max_fd = fd1 > fd2 ? fd1 : fd2;

    while(1){
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds); 
        FD_SET(fd1, &rfds);
        FD_SET(fd2, &rfds);

        tv.tv_sec = 5;
        tv.tv_usec = 0;

        // Seleccionar el descriptor más grande y agregar 1
        int retval = select(max_fd + 1, &rfds, NULL, NULL, &tv);
        if(retval == -1){
            perror("select");
            exit(EXIT_FAILURE);
        }else if(retval){
            // Verificar si stdin está listo (CTRL+D)
            if(FD_ISSET(STDIN_FILENO, &rfds)){
                if(read(STDIN_FILENO, buf, sizeof(buf)) == 0){
                    // EOF recibido, terminar el programa
                    printf("CTRL+D presionado, saliendo.\n");
                    break;
                }
            }
            if(FD_ISSET(fd1, &rfds)){
                ssize_t readBytes = read(fd1, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Leído desde %s: %s\n", nombre_tubería1, buf);
                }
            }
            if(FD_ISSET(fd2, &rfds)){
                ssize_t readBytes = read(fd2, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Leído desde %s: %s\n", nombre_tubería2, buf);
                }
            }
        }else{
            printf("No hay datos en cinco segundos.\n");
        }
    }

    close(fd1);
    close(fd2);
    unlink(nombre_tubería1);
    unlink(nombre_tubería2);

    return 0;
}

