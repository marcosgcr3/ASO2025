#include <stdio.h>
#include <stdlib.h>
#include <sys/inotify.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h> 

#define MAXMSJ 1024  // Definición del tamaño máximo del mensaje
#define MAILBOX "mailbox"  // Nombre del archivo mailbox

// En este ejercicio, un padre y un hijo se comunican mediante inotify y un archivo (mailbox), repitiendo el intercambio hasta que el padre recibe CTRL + DS
// Se utiliza inotify en vez de señales (ej2 p4), y se cierra el mailbox al acabar.

int main() {
    char mensaje[MAXMSJ]; 
    pid_t pid;  
    int pauseSecs = 1;  
    char *val;  

    // Obtener el valor de la variable de entorno PAUSASECS
    val = getenv("PAUSASECS");
    if (val != NULL) {
        pauseSecs = atoi(val); // Si PAUSASECS está definida, usar su valor
    }

    // Crear el archivo "mailbox" si no existe, después lo cierra
    FILE *mailbox = fopen(MAILBOX, "w");
    if (mailbox == NULL) {
        perror("Error al crear mailbox");
        exit(1);
    }
    fclose(mailbox);  

    pid = fork();  // Crear un proceso hijo
    if (pid == -1) {
        perror("Error en fork");
        return 1;
    }

    if (pid > 0) {  // Proceso padre
        while (fgets(mensaje, MAXMSJ, stdin) != NULL) {  // Leer mensaje desde la entrada estándar
            // Abrir el archivo "mailbox" en modo escritura
            mailbox = fopen(MAILBOX, "w");
            if (mailbox == NULL) {
                perror("Error al abrir archivo");
                exit(1);
            }
            fputs(mensaje, mailbox); // Escribir el mensaje en el archivo
            fflush(mailbox);  // Asegurar que el mensaje se escribe inmediatamente
            fclose(mailbox);  // Cerrar el archivo

            // Pausar por el tiempo definido en pauseSecs
            sleep(pauseSecs);
        }
           
      	printf("Eliminando mailbox y finalizando proceso padre.\n");
        remove(MAILBOX);  // Eliminar el archivo "mailbox"
    } else {  // Proceso hijo
        int fd, wd;
        char buffer[sizeof(struct inotify_event) + NAME_MAX + 1];  // Buffer para leer eventos de inotify

        // Inicializar inotify
        fd = inotify_init();
        if (fd < 0) {
            perror("Error al inicializar inotify");
            exit(1);
        }

        // Agregar un watch para el archivo "mailbox" con el evento IN_MODIFY (modificación)
        wd = inotify_add_watch(fd, MAILBOX, IN_MODIFY);
        if (wd == -1) {
            perror("Error al agregar watch a mailbox");
            exit(1);
        }

        while (1) {        	
            // Leer el evento de inotify
            int length = read(fd, buffer, sizeof(buffer));
            if (length < 0) {
                perror("Error en read");
                exit(1);
            }

            // Abrir el archivo "mailbox" en modo lectura
            mailbox = fopen(MAILBOX, "r");
            if (mailbox == NULL) {
                //perror("Hijo no puede abrir el archivo");
                break;
            }

            // Leer el mensaje del archivo y mostrarlo en consola
            if (fgets(mensaje, MAXMSJ, mailbox) != NULL) {
                printf("Hijo recibió: %s", mensaje);
            }

            fclose(mailbox);  // Cerrar el archivo
        }

        // Eliminar el watch de inotify y cerrar el descriptor de archivo
        inotify_rm_watch(fd, wd);
        printf("Hijo eliminando el watch de inotify\n");
        close(fd);
    }

    return 0;  // Finalizar el programa
}
