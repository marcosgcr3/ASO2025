#include <stdio.h>
#include <stdlib.h>
#include <sys/inotify.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/stat.h>

#define MAXMSJ 1024 // Tamaño máximo del mensaje
#define NUM_CHILDREN 3 // Número de hijos

// En este ejercicio, un padre y unos hijos se comunican mediante inotify y un archivo (mailbox), repitiendo el intercambio hasta que el padre recibe CTRL + DS
// Cada hijo tiene su mailbox privado, El mensaje se copiará a todos los mailboxes y el padre deberá:
	// • Detectar cuando ha finalizado la lectura en cada uno de los hijos.
	// • Informará por la salida estándar qué hijo ha leido su buzón.
	// • No volverá a solicitar un nuevo mensaje hasta que todos los no hayan completado la lectura de sus correspondientes buzones.

// Se utiliza inotify en vez de señales (ej2 p4), y se cierra el mailbox al acabar.

int main() {
    char mensaje[MAXMSJ];
    pid_t pid[NUM_CHILDREN];
    int pauseSecs = 1;
    char *val;
    char *mailboxes[NUM_CHILDREN]; // Array unidimensional para los nombres de los buzones
    int hijosListos[NUM_CHILDREN] = {0}; // Bandera para detectar cuando cada hijo ha leído su buzón

    // Crear nombres de buzones privados (mailbox1, mailbox2, ...)
    for (int i = 0; i < NUM_CHILDREN; i++) {
        mailboxes[i] = malloc(20); // Reservar memoria para cada nombre
        if (mailboxes[i] == NULL) {
            perror("Error al asignar memoria para mailbox");
            exit(1);
        }
        snprintf(mailboxes[i], 20, "mailbox%d", i + 1); // Crear el nombre del buzón
        FILE *mailbox = fopen(mailboxes[i], "w"); // Crear el buzón si no existe
        if (mailbox == NULL) {
            perror("Error al crear mailbox");
            exit(1);
        }
        fclose(mailbox); // Cerrar el archivo
    }

    // Obtener el valor de la variable de entorno PAUSASECS
    val = getenv("PAUSASECS");
    if (val != NULL) {
        pauseSecs = atoi(val); // Si PAUSASECS está definida, usar su valor
    }

    // Crear múltiples procesos hijos
    for (int i = 0; i < NUM_CHILDREN; i++) {
        pid[i] = fork();
        if (pid[i] == -1) {
            perror("Error en fork");
            exit(1);
        }
        if (pid[i] == 0) { // Código del hijo
            int fd_inotify, wd;
            char buffer[sizeof(struct inotify_event) + NAME_MAX + 1];

            // Inicializar inotify
            fd_inotify = inotify_init();
            if (fd_inotify < 0) {
                perror("Error al inicializar inotify");
                exit(1);
            }

            // Agregar un watch para el archivo privado (mailboxX)
            wd = inotify_add_watch(fd_inotify, mailboxes[i], IN_MODIFY);
            if (wd == -1) {
                perror("Error al agregar watch a mailbox");
                exit(1);
            }

            while (1) {
                // Leer el evento de inotify
                int length = read(fd_inotify, buffer, sizeof(buffer));
                if (length < 0) {
                	break;
                    perror("Error al leer inotify");
                    exit(1);
                }

                int fd = open(mailboxes[i], O_RDWR); // Abrir el buzón con permiso de lectura/escritura
                if (fd == -1) {
                	break;
                    perror("Hijo no puede abrir mailbox");
                    exit(1);
                }

                // Leer el contenido del buzón
                int bytesRead = read(fd, mensaje, MAXMSJ);
                if (bytesRead > 0) {
                    mensaje[bytesRead] = '\0'; // Asegurar que el mensaje esté terminado
                    printf("Hijo %d recibió: %s", getpid(), mensaje);

                    // Crear un archivo marcador para indicar al padre que este hijo ha leído
                    char marker[20];
                    snprintf(marker, sizeof(marker), "ready%d", i + 1);
                    FILE *ready = fopen(marker, "w");
                    if (ready == NULL) {
                        perror("Error al crear archivo marcador");
                        exit(1);
                    }
                    fclose(ready); // Cerrar el marcador

                    // Limpiar el contenido del buzón después de leerlo
                    ftruncate(fd, 0);
                }
                close(fd);
            }

            // Eliminar el watch de inotify y cerrar el descriptor
            printf("Hijo %d eliminando el watch de inotify\n", getpid());
            inotify_rm_watch(fd_inotify, wd);
            close(fd_inotify);
            exit(0);
        }
    }

    // Código del padre
    if (pid[0] > 0) {
        while (fgets(mensaje, MAXMSJ, stdin) != NULL) {
            // Escribir el mensaje en todos los buzones
            for (int i = 0; i < NUM_CHILDREN; i++) {
                int fd = open(mailboxes[i], O_WRONLY | O_TRUNC); // Abrir el buzón y limpiar contenido
                if (fd == -1) {
                    perror("Error al abrir mailbox");
                    exit(1);
                }
                write(fd, mensaje, strlen(mensaje)); // Escribir el mensaje
                close(fd);
            }

            // Esperar a que todos los hijos hayan leído sus buzones
            memset(hijosListos, 0, sizeof(hijosListos)); // Reiniciar el estado de los hijos listos
            int hijosCompletados = 0;
            while (hijosCompletados < NUM_CHILDREN) {
                for (int i = 0; i < NUM_CHILDREN; i++) {
                    if (!hijosListos[i]) {
                        char marker[20];
                        snprintf(marker, sizeof(marker), "ready%d", i + 1);
                        if (access(marker, F_OK) == 0) { // Verificar si el archivo marcador existe
                            printf("Padre: Hijo %d ha leído su buzón.\n", pid[i]);
                            hijosListos[i] = 1;
                            hijosCompletados++;
                            remove(marker); // Eliminar el archivo marcador
                        }
                    }
                }
                usleep(100000); // Pausa breve para evitar demasiadas iteraciones
            }

            sleep(pauseSecs); // Pausa antes de enviar el siguiente mensaje
        }

        // Finalizar: Eliminar los buzones y esperar a los hijos
        printf("Eliminando mailboxes y finalizando proceso padre.\n");
        for (int i = 0; i < NUM_CHILDREN; i++) {
            remove(mailboxes[i]); // Eliminar los buzones
            free(mailboxes[i]); // Liberar memoria para el nombre del buzón
        }
        for (int i = 0; i < NUM_CHILDREN; i++) {
            kill(pid[i], SIGTERM); // Terminar los hijos
            wait(NULL); // Asegurar la finalización
        }
    }

    return 0;
}
