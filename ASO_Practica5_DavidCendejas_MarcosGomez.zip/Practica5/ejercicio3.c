#include <stdio.h>
#include <stdlib.h>
#include <sys/inotify.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/stat.h>
#include <signal.h>

#define MAXMSJ 1024 
#define NUM_CHILDREN 3 // Número de hijos

int main() {
    char mensaje[MAXMSJ]; 
    pid_t pid[NUM_CHILDREN]; 
    int pauseSecs = 1; 
    char *val;
    char *mailboxes[NUM_CHILDREN]; // Array para los nombres de los buzones
    int hijosListos[NUM_CHILDREN] = {0}; // Array para marcar si los hijos han leído el mensaje

    // Crear los buzones (mailboxes) y asignar nombres únicos
    for (int i = 0; i < NUM_CHILDREN; i++) {
        mailboxes[i] = malloc(20); // Reservar memoria para el nombre del buzón
        if (mailboxes[i] == NULL) {
            perror("malloc"); 
            exit(1);
        }
        snprintf(mailboxes[i], 20, "mailbox%d", i + 1); // Crear el nombre del buzón
        FILE *mailbox = fopen(mailboxes[i], "w"); // Crear un archivo vacío para el buzón
        if (mailbox == NULL) {
            perror("fopen"); 
            exit(1);
        }
        fclose(mailbox); 
    }

    // Obtener el valor de la variable de entorno PAUSASECS (si está definida)
    val = getenv("PAUSASECS");
    if (val != NULL)
        pauseSecs = atoi(val); 

    // Crear los procesos hijos
    for (int i = 0; i < NUM_CHILDREN; i++) {
        pid[i] = fork();
        if (pid[i] == -1) {
            perror("fork"); 
            exit(1);
        }
        if (pid[i] == 0) { // Código de los hijos
            // Inicializar inotify para monitorear el buzón
            int fd_inotify = inotify_init();
            if (fd_inotify < 0) {
                perror("inotify_init");
                exit(1);
            }

            // Agregar un watch al buzón para detectar modificaciones (IN_MODIFY)
            int wd = inotify_add_watch(fd_inotify, mailboxes[i], IN_MODIFY);
            if (wd == -1) {
                perror("inotify_add_watch");
                exit(1);
            }

            char buffer[sizeof(struct inotify_event) + NAME_MAX + 1]; // Buffer para eventos de inotify

            while (1) { // Bucle infinito para procesar cambios en el buzón
                int length = read(fd_inotify, buffer, sizeof(buffer)); // Leer eventos
                if (length < 0) {
                    break; // Romper el bucle si hay un error
                }

                // Abrir el buzón para leer el mensaje
                int fd = open(mailboxes[i], O_RDWR);
                if (fd == -1) {
                    break; // Romper el bucle si no se puede abrir el buzón
                }

                // Leer el contenido del buzón
                int bytesRead = read(fd, mensaje, MAXMSJ - 1);
                if (bytesRead > 0) {
                    mensaje[bytesRead] = '\0'; 
                    printf("Hijo %d recibió: %s", getpid(), mensaje);
                    fflush(stdout); // Asegurar que se imprime el mensaje
                    ftruncate(fd, 0); // Limpiar el contenido del buzón tras leerlo
                }
                close(fd); 
            }

            // Eliminar el watch y cerrar inotify cuando el proceso hijo termina
            printf("Hijo %d eliminando el watch de inotify\n", getpid());
            inotify_rm_watch(fd_inotify, wd);
            close(fd_inotify);
            exit(0); // Salir del proceso hijo
        }
    }

    // Código del proceso padre
    if (pid[0] > 0) {
        // Inicializar inotify para el padre
        int fd_inotify = inotify_init();
        if (fd_inotify < 0) {
            perror("inotify_init padre");
            exit(1);
        }

        // Agregar watches para todos los buzones
        int wds[NUM_CHILDREN];
        for (int i = 0; i < NUM_CHILDREN; i++) {
            wds[i] = inotify_add_watch(fd_inotify, mailboxes[i], IN_MODIFY);
            if (wds[i] == -1) {
                perror("inotify_add_watch padre");
                exit(1);
            }
        }

        char buffer[sizeof(struct inotify_event) + NAME_MAX + 1]; // Buffer para eventos de inotify

        while (fgets(mensaje, MAXMSJ, stdin) != NULL) { // Leer mensajes desde stdin
            // Escribir el mensaje en todos los buzones
            for (int i = 0; i < NUM_CHILDREN; i++) {
                int fd = open(mailboxes[i], O_WRONLY | O_TRUNC); // Abrir el buzón en modo escritura
                if (fd == -1) {
                    perror("open padre");
                    exit(1);
                }
                write(fd, mensaje, strlen(mensaje)); // Escribir el mensaje en el buzón
                close(fd);
                hijosListos[i] = 0; // Marcar al hijo como pendiente de leer
            }

            int hijosCompletados = 0; // Contador de hijos que han leído el mensaje
            while (hijosCompletados < NUM_CHILDREN) {
                int length = read(fd_inotify, buffer, sizeof(buffer)); // Leer eventos
                if (length < 0) {
                    perror("read inotify padre");
                    exit(1);
                }

                int offset = 0; // Desplazamiento para procesar eventos múltiples
                while (offset < length) {
                    struct inotify_event *event = (struct inotify_event *) &buffer[offset];
                    for (int i = 0; i < NUM_CHILDREN; i++) {
                        if (event->wd == wds[i] && !hijosListos[i]) {
                            // Confirmar que el hijo ha leído el buzón
                            hijosListos[i] = 1;
                            hijosCompletados++;
                            printf("Padre: Hijo %d ha leído su buzón.\n", pid[i]);
                            fflush(stdout);
                        }
                    }
                    offset += sizeof(struct inotify_event) + event->len; // Avanzar al siguiente evento
                }
            }

            sleep(pauseSecs); // Pausa antes de solicitar el siguiente mensaje
        }

        // Finalización del padre
        printf("Padre finalizando y eliminando mailboxes.\n");
        for (int i = 0; i < NUM_CHILDREN; i++) {
            remove(mailboxes[i]); // Eliminar los buzones
            free(mailboxes[i]); // Liberar la memoria asignada para los nombres
        }

        // Esperar a que terminen todos los hijos
        for (int i = 0; i < NUM_CHILDREN; i++) {
            wait(NULL); 
        }

        close(fd_inotify); // Cerrar el descriptor de inotify
    }

    return 0; // Fin del programa
}
