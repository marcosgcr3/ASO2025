#ifndef FILTRO_SEPIA_H
#define FILTRO_SEPIA_H

#include "ppm.h"

void filtro_sepia(ImagenPPM *img);

#endif