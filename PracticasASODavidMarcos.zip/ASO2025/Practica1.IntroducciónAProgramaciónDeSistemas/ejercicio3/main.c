#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dlfcn.h>
#include "ppm.h"

//Ejercicio 3. API dlopen 

/* Modificar el programa de test del Ejercicio 2 con librerías dinámicas de modo que:
	• La librería dinámica (libppmaso.so) solo incluirá el código objeto de las funciones leer_ppm,
guardar_ppm y liberar_ppm.
	• Cada uno de los filtros desarrollados (filtro_gris y filtro_sepia) tendrá su propia librería dinámica y
se cargarán dinámicamente con dlopen() como plugins de la aplicación sólo cuando se vayan a utilizar.
*/

typedef void (*filtro_func_t)(ImagenPPM *);

void cargar_y_ejecutar_filtro(ImagenPPM *img, const char *lib_path, const char *func_name) {
    void *manejador;
    filtro_func_t filtro_func;
    char *error;

    // Limpiar errores previos
    dlerror();

    // Cargar la librería
    manejador = dlopen(lib_path, RTLD_LAZY);
    if (!manejador) {
        fprintf(stderr, "Error al cargar la librería %s: %s\n", lib_path, dlerror());
        exit(EXIT_FAILURE);
    }

    // Obtener el puntero a la función
    filtro_func = (filtro_func_t) dlsym(manejador, func_name);
    if ((error = dlerror()) != NULL) {
        fprintf(stderr, "Error al cargar la función %s: %s\n", func_name, error);
        dlclose(manejador);
        exit(EXIT_FAILURE);
    }

    // Ejecutar la función
    filtro_func(img);

    // Cerrar la librería
    dlclose(manejador);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Uso: %s <imagen_entrada.ppm> <filtro>\n", argv[0]);
        printf("Filtros disponibles: gris, sepia\n");
        return 1;
    }

    const char *imagen_entrada = argv[1];
    const char *filtro = argv[2];

    // Leer imagen PPM
    ImagenPPM *img = leer_ppm(imagen_entrada);
    if (!img) {
        printf("Error al leer la imagen: %s\n", imagen_entrada);
        return 1;
    }

    // Aplicar filtro según el argumento
    if (strcmp(filtro, "gris") == 0) {
        cargar_y_ejecutar_filtro(img, "./libfiltro_gris.so", "filtro_gris");
    } else if (strcmp(filtro, "sepia") == 0) {
        cargar_y_ejecutar_filtro(img, "./libfiltro_sepia.so", "filtro_sepia");
    } else {
        printf("Filtro no válido: %s\n", filtro);
        printf("Filtros disponibles: gris, sepia\n");
        liberar_ppm(img);
        return 1;
    }

    // Crear nombre de archivo de salida
    char imagen_salida[256];
    snprintf(imagen_salida, sizeof(imagen_salida), "%s_%s.ppm", imagen_entrada, filtro);

    // Guardar la imagen con el filtro aplicado
    guardar_ppm(imagen_salida, img);
    printf("Imagen procesada y guardada como: %s\n", imagen_salida);

    // Liberar memoria
    liberar_ppm(img);

    return 0;
}
