#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ppm.h"
#include "filtro_gris.h"
#include "filtro_sepia.h"

// Ejercicio 2. Make y creación de librerías

/*
	- Construir una librería estática (libppmaso.a) que incluya el código objeto de las funciones y compile nuestro programa contra esta librería en lugar 
	  de enlazarla con los ficheros objeto correspondientes. Crear un fichero makefile que automatice la creación de la librería estática y genere el 
	  ejecutable de test enlazando con dicha librería estática

	- Lo mismo pero dinámica (libppmaso.so)

	- Fusionar en un único makefile la construcción de ambas librerías (estática y dinámica) y la creación de dos ejecutables de test (appstatic enlazado 
	  contra la librería estática y appdynamic contra la dinámica).
*/

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Uso: %s <imagen_entrada.ppm> <filtro>\n", argv[0]);
        printf("Filtros disponibles: gris, sepia\n");
        return 1;
    }

    const char *imagen_entrada = argv[1];
    const char *filtro = argv[2];

    // Leer imagen PPM
    ImagenPPM *img = leer_ppm(imagen_entrada);
    if (!img) {
        printf("Error al leer la imagen: %s\n", imagen_entrada);
        return 1;
    }

    // Aplicar filtro según el argumento
    if (strcmp(filtro, "gris") == 0) {
        filtro_gris(img);
    } else if (strcmp(filtro, "sepia") == 0) {
        filtro_sepia(img);
    } else {
        printf("Filtro no válido: %s\n", filtro);
        printf("Filtros disponibles: gris, sepia\n");
        liberar_ppm(img);
        return 1;
    }

    // Crear nombre de archivo de salida
    char imagen_salida[256];
    snprintf(imagen_salida, sizeof(imagen_salida), "%s_%s.ppm", imagen_entrada, filtro);

    // Guardar la imagen con el filtro aplicado
    guardar_ppm(imagen_salida, img);
    printf("Imagen procesada y guardada como: %s\n", imagen_salida);

    // Liberar memoria
    liberar_ppm(img);

    return 0;
}
