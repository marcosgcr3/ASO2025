#include <stdio.h>
#include <stdlib.h>
#include <sys/inotify.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h>

#define MAXMSJ 1024
#define MAILBOX "mailbox"
#define NUM_CHILDREN 3 // Número de hijos

// En este ejercicio, un padre y N hijos se comunican mediante inotify y un archivo (mailbox), repitiendo el intercambio hasta que el padre recibe CTRL + D
// El primer hijo que consigue acceder al mailbox será el que lo escriba en consola
// SE UTILIZA UN LOCK DE FICHEROS 
// Se utiliza inotify en vez de señales (ej2 p4), y se cierra el mailbox al acabar.


int main() {
    char mensaje[MAXMSJ];
    pid_t pid;
    int pauseSecs = 1;
    char *val;

    // Obtener el valor de la variable de entorno PAUSASECS
    val = getenv("PAUSASECS");
    if (val != NULL) {
        pauseSecs = atoi(val); // Si PAUSASECS está definida, usar su valor
    }

    // Crear el archivo "mailbox" si no existe
    FILE *mailbox = fopen(MAILBOX, "w");
    if (mailbox == NULL) {
        perror("Error al crear mailbox");
        exit(1);
    }
    fclose(mailbox);

    // Crear múltiples procesos hijos
    for (int i = 0; i < NUM_CHILDREN; i++) {
        pid = fork();
        if (pid == -1) {
            perror("Error en fork");
            exit(1);
        }
        if (pid == 0) { // Código del hijo
            int fd_inotify, wd;
            char buffer[sizeof(struct inotify_event) + NAME_MAX + 1];

            // Inicializar inotify
            fd_inotify = inotify_init();
            if (fd_inotify < 0) {
                perror("Error al inicializar inotify");
                exit(1);
            }

            // Agregar un watch para el archivo "mailbox" con el evento IN_MODIFY
            wd = inotify_add_watch(fd_inotify, MAILBOX, IN_MODIFY);
            if (wd == -1) {
                perror("Error al agregar watch a mailbox");
                exit(1);
            }

            while (1) {
                // Leer el evento de inotify
                int length = read(fd_inotify, buffer, sizeof(buffer));
                if (length < 0) {
                    perror("Error al leer inotify");
                    exit(1);
                }

                int fd = open(MAILBOX, O_RDWR); // Abrir archivo con permiso de lectura/escritura
                if (fd == -1) {
                    //perror("Hijo no puede abrir mailbox");
                    break;
                    exit(1);
                }

                // Intentar obtener un lock exclusivo
                if (flock(fd, LOCK_EX) == 0) {
                    // Leer el contenido del archivo
                    int bytesRead = read(fd, mensaje, MAXMSJ);
                    if (bytesRead > 0) {
                        mensaje[bytesRead] = '\0'; // Asegurarse de que el mensaje esté terminado
                        printf("Hijo %d recibió: %s", getpid(), mensaje);

                        // Limpiar el contenido del archivo después de leerlo
                        ftruncate(fd, 0);
                    }
                    flock(fd, LOCK_UN); // Liberar el lock
                }

                close(fd);
                usleep(100000); // Pausa breve para evitar demasiadas iteraciones
            }

            // Eliminar el watch de inotify y cerrar el descriptor
            printf("Hijo %d eliminando el watch de inotify\n", getpid());
            inotify_rm_watch(fd_inotify, wd);
            close(fd_inotify);
            exit(0);
        }
    }

    // Código del padre
    if (pid > 0) {
    	int fd, wd;
    	char buffer[sizeof(struct inotify_event) + NAME_MAX + 1];
	
    	// Inicializar inotify
    	fd = inotify_init();
    	if (fd < 0) {
        	perror("Error al inicializar inotify");
        	exit(1);
    	}
	
    	// Agregar un watch para el archivo "mailbox" con el evento IN_ACCESS (lectura)
    	wd = inotify_add_watch(fd, MAILBOX, IN_ACCESS);
    	if (wd == -1) {
        	perror("Error al agregar watch a mailbox");
        	exit(1);
    	}
    
        while (fgets(mensaje, MAXMSJ, stdin) != NULL) {
            // Abrir el archivo "mailbox" en modo escritura
        	mailbox = fopen(MAILBOX, "w");
        	if (mailbox == NULL) {
            	perror("Error al abrir archivo");
            	exit(1);
        	}
        	fputs(mensaje, mailbox);  // Escribir el mensaje en el archivo
        	fflush(mailbox);  // Asegurar que el mensaje se escribe inmediatamente
        	fclose(mailbox);  // Cerrar el archivo
	
        	// Esperar a que el hijo lea el archivo
        	int length = read(fd, buffer, sizeof(buffer));
        	if (length < 0) {
            	perror("Error en read");
            	exit(1);
        	}
	
        	// Pausar por el tiempo definido en pauseSecs
        	sleep(pauseSecs);
        }

        // Limpiar inotify
    	inotify_rm_watch(fd, wd);
    	close(fd);
	
    	printf("Eliminando mailbox y finalizando proceso padre.\n");
    	remove(MAILBOX);  // Eliminar el archivo "mailbox"

        // Esperar a que terminen todos los hijos
        for (int i = 0; i < NUM_CHILDREN; i++) {
            wait(NULL);
        }
    }

    return 0;
}
