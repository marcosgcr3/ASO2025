#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>

// Ejercicio 1 : Señales Periódicas

// Este programa mandará cada x segundos un mensaje. Además ignorará CTRL + C, por lo que para finalizarlo hay que mandarle la señal SIGTERM
// Abrir otra terminal, escribir "ps aux | grep mensaje", esto nos dará el pid(ej. 12345), por lo que podremos hacer el comando kill -SIGTERM 12345 

int running = 1;
time_t start_time;

//Cuando le llega un SIGTERM (kill), finaliza
void handle_sigterm(int signum) {    
    time_t end_time = time(NULL);
    printf("\nProceso finalizado. Tiempo transcurrido: %ld segundos.\n", end_time - start_time);
    running = 0;
}

// Cuando le llega un CTRL + C, lo ignora
void handle_sigint(int signum) {     
    printf("\nSeñal SIGINT (CTRL+C) ignorada.\n");
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Uso: %s segundos [mensaje_opcional]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

	// Se obtiene el periodo
    int segundos = atoi(argv[1]);
    if (segundos <= 0) {
        fprintf(stderr, "El periodo debe ser un entero positivo.\n");
        exit(EXIT_FAILURE);
    }

	// Se obtiene el mensaje, en caso de que no hubiese, asigna uno por defecto
    char *mensaje = (argc > 2) ? argv[2] : "No hay mensaje! :(";

    // Capturar SIGTERM y SIGINT
    signal(SIGTERM, handle_sigterm);
    signal(SIGINT, handle_sigint);

    start_time = time(NULL);
    while (running) {
        printf("%s\n", mensaje);
        sleep(segundos);
    }
    return 0;
}
