#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <mqueue.h>

#define SERVER_QUEUE "/file_server_queue"  // Nombre de la cola de mensajes del servidor
#define MAX_MSG_SIZE 8192  
#define MAX_PATH 1024  

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// 	Ejemplo de uso: 
//		- Recordar usar flags adecuadas: gcc -o client file_client.c -lrt 
//										 gcc -o server file_server.c -lrt -lpthread
//
//		- Se ejecuta el servidor con: ./server &
//		- Se ejecutan los clientes con: ./client home/usuarioso/Desktop/hola.txt    (es importante poner la ruta completa del archivo)
//		
//	Detalles de la práctica:
//		- El proceso servidor debe ser un demonio System V (Tiene una serie de requisitos como cerrar los descriptores de fichero, eliminar variables
//		  de entorno, hacer un doble fork(), etc...)
//		- La comunicación entre clientes y servidor se realiza con colas de mensaje POSIX, que a diferencia de los Sistem V, los mensajes tienen una 
//		  prioridad de encolamiento
//		- En el proceso servidor, en lugar de utilizar procesos hijos para transferir los ficheros solicitados a los clientes se utilizarán threads. Para
// 		  implementar esta funcionalidad se utilizará mq_notify
//
//		NOTA: Finalmente no he usado el sfile.h de la plantilla, no me ha hecho falta
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Estructura de la solicitud del cliente
struct request {
    char client_queue[64];  // Cola del cliente
    char filepath[MAX_PATH];  // Ruta del archivo
};

// Función que convierte el proceso en un demonio (daemon)
static void becomeDaemon(void) {
    pid_t pid;

    pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);  // Si el fork falla, salimos
    if (pid > 0) exit(EXIT_SUCCESS);  // El padre muere

    if (setsid() == -1) exit(EXIT_FAILURE);  // Crea una nueva sesión (esto hace q se desvincule de la terminal), si falla, salimos
	
	// Restablecer todos los manejadores de señales al manejador por defecto
	signal(SIGCHLD, SIG_IGN);
    signal(SIGHUP, SIG_IGN);

    pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);  // Si el fork falla, salimos
    if (pid > 0) exit(EXIT_SUCCESS);  // El segundo hijo muere, aseguramos que el proceso sea un daemon

    umask(0);  // Establece los permisos por defecto
    chdir("/");  // Cambia el directorio de trabajo a la raíz
	
	// Cierra las entradas, salidas y errores estándar
    close(STDIN_FILENO);  
    close(STDOUT_FILENO);  
    close(STDERR_FILENO);  
    
    // Redirige stdin, stdout y stderr a /dev/null
    open("/dev/null", O_RDWR);  
    dup(0); 
    dup(0);  
}

// Función que envía el archivo al cliente a través de la cola de mensajes
static void send_file(const char* filepath, const char* client_queue_name) {

    mqd_t client_q = mq_open(client_queue_name, O_WRONLY);  // Abre la cola de mensajes del cliente
    
    if (client_q == (mqd_t)-1) return;  					// Si no se pudo abrir la cola, salimos

    int fd = open(filepath, O_RDONLY);  					// Abre el archivo en modo solo lectura
    printf("Ruta del archivo: %s\n", filepath);  	// DEBUG
    
    char buffer[MAX_MSG_SIZE];  							// Buffer para almacenar los datos leídos del archivo

    // Si no se pudo abrir el archivo, enviamos un mensaje de error al cliente
    if (fd == -1) {
        snprintf(buffer, sizeof(buffer), "ERROR: Could not open file:%s", filepath);
        mq_send(client_q, buffer, strlen(buffer) + 1, 1);  	// Envia el mensaje de error al cliente
        mq_close(client_q);  								// Cierra la cola del cliente
        return;
    }

	// Lee el archivo en bloques y lo envía al cliente
    ssize_t bytes;
    while ((bytes = read(fd, buffer, MAX_MSG_SIZE)) > 0) {
        mq_send(client_q, buffer, bytes, 2);  				// Envía los datos al cliente
    }

    // Señal de finalización (se envía un mensaje vacío para indicar que ya terminó)
    mq_send(client_q, "", 0, 3);
    close(fd);  											// Cierra el archivo
    mq_close(client_q);  									// Cierra la cola del cliente
}

// Hilo que maneja la recepción de solicitudes desde la cola del servidor
//La función handler_thread no se llama directamente por el código, sino que es invocada automáticamente por el sistema operativo cuando llega un mensaje a la cola del servidor. Esto ocurre gracias a la funcionalidad de notificación mq_notify con el tipo SIGEV_THREAD.
static void handler_thread(union sigval sv) {
    mqd_t server_q = *((mqd_t *) sv.sival_ptr);  			// Obtiene la cola del servidor
    struct mq_attr attr;
    mq_getattr(server_q, &attr);  							// Obtiene los atributos de la cola

    char* msg_buf = malloc(attr.mq_msgsize);  				// Buffer para almacenar el mensaje recibido
    unsigned prio;  // Prioridad del mensaje

    struct sigevent sev = {
        .sigev_notify = SIGEV_THREAD,  				// Notificación a través de hilo
        .sigev_notify_function = handler_thread,  	// Función de callback
        .sigev_notify_attributes = NULL,
        .sigev_value.sival_ptr = sv.sival_ptr  		// Puntero a la cola del servidor
    };

    // Establece la notificación para recibir nuevos mensajes
    if (mq_notify(server_q, &sev) == -1) {
        perror("mq_notify");
        exit(EXIT_FAILURE);  								// Si falla la notificación, salimos
    }

    // Bucle que procesa los mensajes recibidos en la cola
    while (mq_receive(server_q, msg_buf, attr.mq_msgsize, &prio) != -1) {
        struct request* req = (struct request*) msg_buf;  	// Convierte el mensaje a una estructura request
        send_file(req->filepath, req->client_queue);  		// Llama a send_file para enviar el archivo
    }

    free(msg_buf); 
}

int main() {
    becomeDaemon();  // Convierte el proceso en un daemon

    // Atributos de la cola del servidor
    struct mq_attr attr = {
        .mq_flags = 0,
        .mq_maxmsg = 10,
        .mq_msgsize = sizeof(struct request),  
        .mq_curmsgs = 0
    };

    mq_unlink(SERVER_QUEUE);  													// Elimina la cola si ya existía
    mqd_t server_q = mq_open(SERVER_QUEUE, O_CREAT | O_RDONLY, 0660, &attr);  	// Abre la cola del servidor
    if (server_q == (mqd_t)-1) exit(EXIT_FAILURE);  							// Si falla al abrir la cola, salimos

    // Establece la notificación para recibir solicitudes de los clientes
    struct sigevent sev = {
        .sigev_notify = SIGEV_THREAD,
        .sigev_notify_function = handler_thread,
        .sigev_notify_attributes = NULL,
        .sigev_value.sival_ptr = &server_q
    };

    // Establece la notificación de mensajes en la cola del servidor
    if (mq_notify(server_q, &sev) == -1) {
        perror("mq_notify");
        exit(EXIT_FAILURE);  // Si falla la notificación, salimos
    }

    // El daemon espera indefinidamente para procesar mensajes
    while (1) pause();

    mq_close(server_q);  		// Cierra la cola del servidor
    mq_unlink(SERVER_QUEUE);  	// Elimina la cola del servidor
    return 0;
}
