#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

/*
Ejercicio 1 Tuberías sin nombre

Escribir un programa que emule el comportamiento de la shell en la ejecución de una sentencia en la forma: comando1 argumento 1 | comando2 argumento2
Para emular este comportamiento el programa creará una tubería sin nombre int pipe(int pipefd[2]) y a continuación creará un proceso hijo: 
	- En el proceso padre se ejecutará “comando1 argumento1”, redireccionando previamente la salida estándar al extremo de escritura del pipe. 
	- En el proceso hijo se ejecutará “comando2 argumento2”, redireccionandose previamente en este caso la entrada estándar al extremo de lectura del pipe.

Ejemplo: para emular la ejecución de ls -l | wc -l, llamaremos a nuestro programa con los siguientes argumentos: ./ejercicio1 ls -l wc -l

Basicamente esto hace que la salida del primer comando sea la entrada del segundo. Por eso el padre linkea la salida de la terminal al pipe y el hijo la entrada, lo que escupe la terminal despues del segundo comando va al pipe en vez de mostrarse.

*/

int main(int argc, char *argv[]) {
    if (argc != 5) {
        fprintf(stderr, "Uso: %s comando1 argumento1 comando2 argumento2\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int pipefd[2];  //pipefd[0] es el extremo de lectura y pipefd[1] el de escritura.
    
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

	// Proceso hijo
    if (pid == 0) { 
        close(pipefd[1]); 				// Cierra el extremo de escritura no necesario
        dup2(pipefd[0], STDIN_FILENO);  // Redirecciona la entrada estándar al extremo de lectura del pipe
        close(pipefd[0]); 				// Ya no se necesita el descriptor original

        execlp(argv[3], argv[3], argv[4], (char *)NULL);
        perror("execlp hijo");
        exit(EXIT_FAILURE);
    } 
    // Proceso padre
    else { 
        close(pipefd[0]); 				// Cierra el extremo de lectura no necesario
        dup2(pipefd[1], STDOUT_FILENO); // Redirecciona la salida estándar al extremo de escritura del pipe
        close(pipefd[1]); 				// Ya no se necesita el descriptor original

        execlp(argv[1], argv[1], argv[2], (char *)NULL);
        perror("execlp padre");
        exit(EXIT_FAILURE);
    }
}
