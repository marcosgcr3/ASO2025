#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <errno.h>
// Ejercicio 2. Comunicación con Tuberías con Nombre
/*
Completar el program del apartado anterior 2.3 añadiendo la posibilidad de que el programa termine cuando el usuario
presione en el terminal CTR+D

Nota: El primer conjunto de descriptores de fichero que se le pasa a select es aquel sobre el que queremos esperar
hasta que haya algún dato que leer. Hay una pequeña excepción. Cuando se alcanza el final de un fichero (o se corta la
comunicación en una tubería o un socket), select se desbloquea si el objeto está entre los especificados en su primer
conjunto de descriptores de fichero. En estos casos al hacer un read sobre uno de ellos, la llamada al sistema devolverá
cero inmediatamente, señal que nos sirve para detectar el fin del fichero o el corte de la comunicación.


*/

int main(int argc, char *argv[]){
    if(argc != 3){
        fprintf(stderr, "Uso: %s <nombre_tubería1> <nombre_tubería2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *nombre_tubería1 = argv[1];
    char *nombre_tubería2 = argv[2];

    if(mkfifo(nombre_tubería1, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }
    if(mkfifo(nombre_tubería2, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    int fd1 = open(nombre_tubería1, O_RDONLY | O_NONBLOCK);
    int fd2 = open(nombre_tubería2, O_RDONLY | O_NONBLOCK);
    if(fd1 == -1 || fd2 == -1){
        perror("open");
        exit(EXIT_FAILURE);
    }

    fd_set rfds;
    struct timeval tv;
    char buf[1024];
    int max_fd = fd1 > fd2 ? fd1 : fd2;   //Se calcula el fd más grande

    while(1){
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);   //Tambien está atento a un CTR+D
        FD_SET(fd1, &rfds);
        FD_SET(fd2, &rfds);

        tv.tv_sec = 5;
        tv.tv_usec = 0;

        // Seleccionar el descriptor más grande y agregar 1 (para que tenga en cuenta todos los anteriores)
        int retval = select(max_fd + 1, &rfds, NULL, NULL, &tv);
        if(retval == -1){
            perror("select");
            exit(EXIT_FAILURE);
        }else if(retval){
            // Verificar si stdin está listo (CTRL+D)
            if(FD_ISSET(STDIN_FILENO, &rfds)){
                if(read(STDIN_FILENO, buf, sizeof(buf)) == 0){
                    // EOF recibido, terminar el programa
                    printf("CTRL+D presionado, saliendo.\n");
                    break;
                }
            }
            // Leer de fd1 si está listo
            if(FD_ISSET(fd1, &rfds)){
                ssize_t readBytes = read(fd1, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Leído desde %s: %s\n", nombre_tubería1, buf);
                }
            }
            // Leer de fd2 si está listo
            if(FD_ISSET(fd2, &rfds)){
                ssize_t readBytes = read(fd2, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Leído desde %s: %s\n", nombre_tubería2, buf);
                }
            }
        }else{
            printf("No hay datos en cinco segundos.\n");
        }
    }

    close(fd1);
    close(fd2);
    unlink(nombre_tubería1);
    unlink(nombre_tubería2);

    return 0;
}

