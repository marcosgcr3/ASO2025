#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/select.h>
#include <errno.h>

// Ejercicio 2. Comunicación con Tuberías con Nombre
/*
Escribir un programa que cree una nueva tubería con nombre (ej. $HOME\tuberia2) y espere con select() hasta
que haya datos listos para leer en alguna de las dos tuberías. El programa debe leer entonces de la tubería correspondiente
y mostrar los datos leídos en la salida estándar, indicando la tubería desde la que se leyó. Usar lecturas no bloqueantes
usando el flag O_NONBLOCK
*/

int main(int argc, char *argv[]){
    if(argc != 3){
        fprintf(stderr, "Usage: %s <pipe_name1> <pipe_name2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *pipe_name1 = argv[1];
    char *pipe_name2 = argv[2];

    // Intentar crear la primera tubería
    if(mkfifo(pipe_name1, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    // Intentar crear la segunda tubería
    if(mkfifo(pipe_name2, 0666) == -1 && errno != EEXIST){
        perror("mkfifo");
        exit(EXIT_FAILURE);
    }

    int fd1 = open(pipe_name1, O_RDONLY | O_NONBLOCK);
    int fd2 = open(pipe_name2, O_RDONLY | O_NONBLOCK);
    if(fd1 == -1 || fd2 == -1){
        perror("open");
        exit(EXIT_FAILURE);
    }

    fd_set rfds;
    struct timeval tv;
    char buf[1024];

    while(1){
        FD_ZERO(&rfds);      //Limpia el conjunto de descriptores de archivo (fd_set) llamado rfds.hacerlo antes de usar FD_SET, para no tener basura
        FD_SET(fd1, &rfds);  //Agrega el descriptor de archivo fd1 al conjunto rfds. 
        FD_SET(fd2, &rfds);  //(Le estás diciendo a select() que quieres esperar a que fd1 y fd2 esté listo para leer.

        // Configurar el timeout
        tv.tv_sec = 5;
        tv.tv_usec = 0;

        int retval = select(fd2 + 1, &rfds, NULL, NULL, &tv);   //espere hasta que haya datos listos para leer 
        if(retval == -1){										//ojo: se le suma 1 para que tenga en cuenta todos los anteriores
            perror("select");
            exit(EXIT_FAILURE);
        }else if(retval){
            // Leer de fd1 si está listo
            if(FD_ISSET(fd1, &rfds)){
                ssize_t readBytes = read(fd1, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Lectura de %s: %s\n", pipe_name1, buf);
                }
            }
            // Leer de fd2 si está listo
            if(FD_ISSET(fd2, &rfds)){
                ssize_t readBytes = read(fd2, buf, sizeof(buf)-1);
                if(readBytes > 0){
                    buf[readBytes] = '\0';
                    printf("Lectura de %s: %s\n", pipe_name2, buf);
                }
            }
        }else{
            printf("Sin datos en los ultimos 5 segundos.\n");
        }
    }

    close(fd1);
    close(fd2);
    unlink(pipe_name1);
    unlink(pipe_name2);

    return 0;
}

