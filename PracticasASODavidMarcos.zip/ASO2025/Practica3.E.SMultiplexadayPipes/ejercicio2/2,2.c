#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

// Ejercicio 2. Comunicación con Tuberías con Nombre
/*
Escribir un programa que abra la tubería con nombre anterior (tuberia1) en modo solo escritura, y escriba en ella el primer argumento del programa. En otro terminal, leer de la tubería usando un comando adecuado. (cat tuberia1)
*/

int main(int argc, char *argv[]){
    if(argc != 3){ // Se espera el nombre de la tubería y el mensaje como argumentos
        printf("Usage: %s <pipe_name> <message>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    char *pipe_name = argv[1];
    char *message = argv[2]; // El mensaje a enviar es ahora el segundo argumento
    int fd;
    if((fd = open(pipe_name, O_WRONLY)) == -1){
        perror("open");
        exit(EXIT_FAILURE);
    }
    if(write(fd, message, strlen(message)) == -1){ // Escribir el mensaje en la tubería
        perror("write");
        exit(EXIT_FAILURE);
    }
    close(fd);
    return 0;
}

