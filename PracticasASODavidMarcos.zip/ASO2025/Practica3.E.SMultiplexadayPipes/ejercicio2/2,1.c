#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <time.h>

// Ejercicio 2. Comunicación con Tuberías con Nombre
// Usar el comando mkfifo para crear una tubería (ej. $HOME\tuberia1). Usar las herramientas del sistema de ficheros (stat, ls. . . ) para determinar sus propiedades. Comprobar su funcionamiento usando utilidades para escribir y leer de ficheros (ej. echo, cat, less, tail).

int main(int argc, char *argv[]) {
    char *pipe_name = "tuberia1"; // Nombre de la tubería
    struct stat statbuf;

    // Verificar si la tubería ya existe
    if (stat(pipe_name, &statbuf) == -1) {
        if (errno == ENOENT) {
            // La tubería no existe, crearla
            if (mkfifo(pipe_name, 0666) == -1) {
                perror("mkfifo");
                exit(EXIT_FAILURE);
            }
            printf("Tubería creada: %s\n", pipe_name);
        } else {
            // Otro error al verificar la tubería
            perror("stat");
            exit(EXIT_FAILURE);
        }
    } else {
        printf("La tubería ya existe: %s\n", pipe_name);
    }

    // Obtener y mostrar las propiedades de la tubería
    if (stat(pipe_name, &statbuf) == 0) {
        printf("Propiedades de la tubería:\n");
        printf("Tipo de archivo: ");
        switch (statbuf.st_mode & S_IFMT) {
            case S_IFBLK: printf("dispositivo de bloque\n"); break;
            case S_IFCHR: printf("dispositivo de caracteres\n"); break;
            case S_IFDIR: printf("directorio\n"); break;
            case S_IFIFO: printf("FIFO/tubería\n"); break;
            case S_IFLNK: printf("enlace simbólico\n"); break;
            case S_IFREG: printf("archivo regular\n"); break;
            case S_IFSOCK: printf("socket\n"); break;
            default: printf("desconocido?\n"); break;
        }
        printf("Número de inodo: %ld\n", (long) statbuf.st_ino);
        printf("Modo: %lo (octal)\n", (unsigned long) statbuf.st_mode);
        printf("Cantidad de enlaces: %ld\n", (long) statbuf.st_nlink);
        printf("Propietario: UID=%ld GID=%ld\n", (long) statbuf.st_uid, (long) statbuf.st_gid);
        printf("Tamaño preferido de E/S: %ld bytes\n", (long) statbuf.st_blksize);
        printf("Tamaño del archivo: %lld bytes\n", (long long) statbuf.st_size);
        printf("Bloques asignados: %lld\n", (long long) statbuf.st_blocks);
        printf("Último cambio de estado: %s", ctime(&statbuf.st_ctime));
        printf("Último acceso al archivo: %s", ctime(&statbuf.st_atime));
        printf("Última modificación del archivo: %s", ctime(&statbuf.st_mtime));
        printf("Archivo: %s\n", pipe_name);
        printf("Tamaño: %lld\tBloques: %lld\tBloque de E/S: %ld\t", (long long) statbuf.st_size, (long long) statbuf.st_blocks, (long) statbuf.st_blksize);
        printf("FIFO\n");
        printf("Acceso: (0666/%o)\n", statbuf.st_mode & 0777);
        printf("UID: ( %ld)\tGID: ( %ld)\n", (long) statbuf.st_uid, (long) statbuf.st_gid);
    } else {
        perror("stat");
        exit(EXIT_FAILURE);
    }

    return 0;
}

